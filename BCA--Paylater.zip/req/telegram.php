<?php
$kennesia_telegram_id = "100xx";
$kennesia_token_bot = "1000xxx";
?>
